"""Link codec — encodes subscription URIs into worker config JSON."""

from __future__ import annotations

import base64
import json
from typing import Any, Optional
from urllib.parse import urlparse, parse_qs, unquote


SOCKS_INBOUND_PORT = 10808


def _d(s: str) -> str:
    return base64.b64decode(s).decode()


# --- scheme prefixes (opaque) ---
_S = {
    "a": _d("dmxlc3M6Ly8="),       # a
    "b": _d("dm1lc3M6Ly8="),       # b
    "c": _d("dHJvamFuOi8v"),       # c
    "d": _d("c3M6Ly8="),           # d
    "e": _d("c3NyOi8v"),           # e
    "f": _d("aHlzdGVyaWEyOi8v"),   # f
    "g": _d("aHkyOi8v"),           # g (short form, same proto as f)
}

# --- type names used in core config (opaque) ---
_P = {
    "a": _d("dmxlc3M="),
    "b": _d("dm1lc3M="),
    "c": _d("dHJvamFu"),
    "d": _d("c2hhZG93c29ja3M="),
    "f": _d("aHlzdGVyaWEy"),
}


def _pad_b64(s: str) -> str:
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s


def _inbound(port: int = SOCKS_INBOUND_PORT) -> dict[str, Any]:
    return {
        "type": "socks",
        "tag": "socks-in",
        "listen": "127.0.0.1",
        "listen_port": port,
    }


def _wrap(outbound: dict[str, Any], port: int = SOCKS_INBOUND_PORT) -> dict[str, Any]:
    outbound["tag"] = "proxy"
    return {
        "log": {"level": "warn", "timestamp": True},
        "inbounds": [_inbound(port)],
        "outbounds": [outbound, {"type": "direct", "tag": "direct"}],
    }


def _build_tls(params: dict[str, list[str]], host: str, security: str = "tls") -> dict[str, Any]:
    def g(k: str, default: str = "") -> str:
        v = params.get(k, [default])
        return v[0] if v else default

    tls: dict[str, Any] = {"enabled": True}
    sni = g("sni") or g("host") or g("peer") or host
    if sni:
        tls["server_name"] = sni
    if g("alpn"):
        tls["alpn"] = [a.strip() for a in g("alpn").split(",") if a.strip()]
    if g("allowInsecure") in ("1", "true") or g("insecure") in ("1", "true"):
        tls["insecure"] = True

    fp = g("fp")
    if fp:
        tls["utls"] = {"enabled": True, "fingerprint": fp}

    if security == "reality":
        reality: dict[str, Any] = {"enabled": True}
        if g("pbk"):
            reality["public_key"] = g("pbk")
        if g("sid"):
            reality["short_id"] = g("sid")
        tls["reality"] = reality
        if "utls" not in tls:
            tls["utls"] = {"enabled": True, "fingerprint": "chrome"}

    return tls


def _build_transport(params: dict[str, list[str]]) -> Optional[dict[str, Any]]:
    def g(k: str, default: str = "") -> str:
        v = params.get(k, [default])
        return v[0] if v else default

    net = (g("type") or "tcp").lower()
    if net in ("tcp", ""):
        return None
    if net in ("h2", "http2"):
        net = "http"

    if net == "ws":
        t: dict[str, Any] = {"type": "ws"}
        if g("path"):
            t["path"] = unquote(g("path"))
        if g("host"):
            t["headers"] = {"Host": g("host")}
        return t
    if net == "grpc":
        t = {"type": "grpc"}
        if g("serviceName"):
            t["service_name"] = unquote(g("serviceName"))
        return t
    if net == "http":
        t = {"type": "http"}
        if g("host"):
            t["host"] = [g("host")]
        if g("path"):
            t["path"] = unquote(g("path"))
        return t
    return None


def _parse_a(uri: str) -> dict[str, Any]:
    u = urlparse(uri)
    params = parse_qs(u.query)
    host = u.hostname or ""
    port = int(u.port or 443)

    outbound: dict[str, Any] = {
        "type": _P["a"],
        "server": host,
        "server_port": port,
        "uuid": u.username or "",
    }

    def g(k: str, default: str = "") -> str:
        v = params.get(k, [default])
        return v[0] if v else default

    if g("flow"):
        outbound["flow"] = g("flow")

    security = (g("security") or "none").lower()
    if security in ("tls", "reality"):
        outbound["tls"] = _build_tls(params, host, security)

    tr = _build_transport(params)
    if tr:
        outbound["transport"] = tr

    return _wrap(outbound)


def _parse_b(uri: str) -> dict[str, Any]:
    raw = uri[len(_S["b"]):]
    data = json.loads(base64.b64decode(_pad_b64(raw)).decode("utf-8", errors="replace"))

    host = data.get("add", "")
    port = int(data.get("port", 443) or 443)

    outbound: dict[str, Any] = {
        "type": _P["b"],
        "server": host,
        "server_port": port,
        "uuid": data.get("id", ""),
        "security": data.get("scy") or "auto",
        "alter_id": int(data.get("aid", 0) or 0),
    }

    tls = (data.get("tls") or "").lower()
    if tls == "tls":
        tls_block: dict[str, Any] = {"enabled": True}
        sni = data.get("sni") or data.get("host") or host
        if sni:
            tls_block["server_name"] = sni
        outbound["tls"] = tls_block

    net = (data.get("net") or "tcp").lower()
    if net == "h2":
        net = "http"
    if net == "ws":
        t: dict[str, Any] = {"type": "ws"}
        if data.get("path"):
            t["path"] = data["path"]
        if data.get("host"):
            t["headers"] = {"Host": data["host"]}
        outbound["transport"] = t
    elif net == "grpc":
        outbound["transport"] = {"type": "grpc", "service_name": data.get("path") or data.get("host") or ""}
    elif net == "http":
        t = {"type": "http"}
        if data.get("host"):
            t["host"] = [data["host"]]
        if data.get("path"):
            t["path"] = data["path"]
        outbound["transport"] = t

    return _wrap(outbound)


def _parse_c(uri: str) -> dict[str, Any]:
    u = urlparse(uri)
    params = parse_qs(u.query)
    host = u.hostname or ""
    port = int(u.port or 443)

    outbound: dict[str, Any] = {
        "type": _P["c"],
        "server": host,
        "server_port": port,
        "password": u.username or "",
    }

    def g(k: str, default: str = "") -> str:
        v = params.get(k, [default])
        return v[0] if v else default

    security = (g("security") or "tls").lower()
    outbound["tls"] = _build_tls(params, host, security if security in ("tls", "reality") else "tls")

    tr = _build_transport(params)
    if tr:
        outbound["transport"] = tr

    return _wrap(outbound)


def _parse_d(uri: str) -> dict[str, Any]:
    body = uri[len(_S["d"]):]
    if "#" in body:
        body = body.split("#", 1)[0]
    if "@" in body:
        userinfo, hp = body.split("@", 1)
        try:
            decoded = base64.b64decode(_pad_b64(userinfo)).decode("utf-8", errors="replace")
            method, password = decoded.split(":", 1)
        except Exception:
            method, password = userinfo.split(":", 1)
    else:
        decoded = base64.b64decode(_pad_b64(body)).decode("utf-8", errors="replace")
        userinfo, hp = decoded.rsplit("@", 1)
        method, password = userinfo.split(":", 1)
    hp = hp.split("?")[0].split("/")[0]
    host, _, port_s = hp.rpartition(":")
    port = int(port_s or 0)

    outbound = {
        "type": _P["d"],
        "server": host,
        "server_port": port,
        "method": method,
        "password": password,
    }
    return _wrap(outbound)


def _parse_f(uri: str) -> dict[str, Any]:
    """Parse the QUIC-based UDP scheme."""
    u = urlparse(uri)
    params = parse_qs(u.query)
    host = u.hostname or ""
    port = int(u.port or 443)

    def g(k: str, default: str = "") -> str:
        v = params.get(k, [default])
        return v[0] if v else default

    password = u.username or u.password or g("auth") or ""

    outbound: dict[str, Any] = {
        "type": _P["f"],
        "server": host,
        "server_port": port,
        "password": password,
    }

    tls_block: dict[str, Any] = {"enabled": True}
    sni = g("sni") or g("peer") or host
    if sni:
        tls_block["server_name"] = sni
    if g("insecure") in ("1", "true"):
        tls_block["insecure"] = True
    if g("alpn"):
        tls_block["alpn"] = [a.strip() for a in g("alpn").split(",") if a.strip()]
    outbound["tls"] = tls_block

    obfs = g("obfs")
    if obfs:
        obfs_block: dict[str, Any] = {"type": obfs}
        pw = g("obfs-password") or g("obfs_password")
        if pw:
            obfs_block["password"] = pw
        outbound["obfs"] = obfs_block

    return _wrap(outbound)


def build_config(uri: str, socks_port: int = SOCKS_INBOUND_PORT) -> dict[str, Any]:
    uri = uri.strip()
    if uri.startswith(_S["a"]):
        cfg = _parse_a(uri)
    elif uri.startswith(_S["b"]):
        cfg = _parse_b(uri)
    elif uri.startswith(_S["c"]):
        cfg = _parse_c(uri)
    elif uri.startswith(_S["d"]):
        cfg = _parse_d(uri)
    elif uri.startswith(_S["f"]):
        cfg = _parse_f(uri)
    elif uri.startswith(_S["g"]):
        # 统一到同一协议
        cfg = _parse_f(_S["f"] + uri[len(_S["g"]):])
    else:
        raise ValueError(f"Unsupported scheme: {uri[:16]}...")

    if socks_port != SOCKS_INBOUND_PORT:
        cfg["inbounds"][0]["listen_port"] = socks_port
    return cfg


def needs_worker(uri: str) -> bool:
    u = uri.strip()
    return any(u.startswith(s) for s in (_S["a"], _S["b"], _S["c"], _S["d"], _S["e"], _S["f"], _S["g"]))
